# 两门麻将 Android 工程

- Android 原生壳：Java + WebView，离线加载 `app/src/main/assets/index.html`。
- 单机四人原型：1 名人类玩家、3 名电脑玩家。
- 复用了上传包中可用的牌桌、牌面等素材（保存在 `original-res/`）。
- 无联网、账号或支付逻辑。

## 构建 APK

需要 Android Studio 或安装 Android SDK（API 35）和 Gradle 8.9+。
在 Android Studio 中打开此目录，等待 Gradle Sync 后选择 Build > Build APK(s)。

## 当前状态

当前执行环境未安装 Android SDK / Gradle，且无法访问外网下载构建工具，因此这里提供的是可导入 Android Studio 的工程，不是已经编译、签名和实机验证的 APK。游戏规则逻辑仍是原型实现，报叫/杀报处罚与胡牌结算还需在后续测试中完善。
